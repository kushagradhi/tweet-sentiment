from sklearn.feature_extraction.text import TfidfVectorizer



def TF_IDF(X_train,X_test):
    vectorizer = TfidfVectorizer(sublinear_tf=True, use_idf=True) #, stop_words='english'
    train_corpus_tf_idf = vectorizer.fit_transform(X_train)
    test_corpus_tf_idf = vectorizer.transform(X_test)
    return (train_corpus_tf_idf,test_corpus_tf_idf)


