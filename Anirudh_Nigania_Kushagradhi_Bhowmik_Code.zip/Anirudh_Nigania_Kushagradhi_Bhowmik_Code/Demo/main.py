import pandas as pd
import numpy as np
from PreProcessing import preProcessing
from Utils import TF_IDF
from imblearn.over_sampling import SMOTE
from collections import Counter
from LogisticRegression import LogisticRegress



filename = "data/trainingObamaRomneytweets.xlsx"
testname = "data/"

for sheet in ['Obama']:
    print ("Start Sentiment Analysis on :",sheet)

    if (sheet=='Obama'):
        testname += "obama_csv_test.csv"
        outname = 'Anirudh_Nigania_Kushagradhi_Bhowmik_Obama.txt'
    else:
        testname += "romney_csv_test.csv"
        outname = 'Anirudh_Nigania_Kushagradhi_Bhowmik_Romney.txt'

    print ("Start Reading Training Data and PreProcessing")
    columns = [3, 4]
    df = pd.read_excel(filename, sheet_name=sheet, usecols=columns, header=1, names=['Tweet', 'Sentiment'])
    df = preProcessing(df,"Train").df
    print ("End Reading Training Data and PreProcessing")


    print ("Start Reading Test Data and PreProcessing")
    tf = pd.read_csv(testname,names=['ID','Tweet'],header=1)
    tf = preProcessing(tf).df
    print ("End Reading Test Data and PreProcessing")

    corpus = [" ".join(tweet) for tweet in df["Tweet"]]
    labels = [int(sentiment) for sentiment in df["Sentiment"]]
    corpus_t = [" ".join(tweet) for tweet in tf["Tweet"]]
    ID = [str(id) for id in tf["ID"]]

    X_train = corpus
    X_test = corpus_t
    y_train = labels

    print ("Start TF_IDF Vectorization")
    train_corpus,test_corpus = TF_IDF(X_train,X_test)
    train_corpus = train_corpus.toarray()
    test_corpus = test_corpus.toarray()
    print ("End TF_IDF Vectorization")

    print ("Start Over Sampling")
    sm = SMOTE(n_jobs=3)
    train_corpus, y_train = sm.fit_resample(train_corpus, y_train)
    print ("End Over Sampling")


    model = LogisticRegress(train_corpus,test_corpus,y_train)
    result = model.evaluate()

    sb = ''
    for i in range(len(tf["ID"])):
        sb += ID[i] + ';;' + str(result[i]) + '\n'

    #print(sb)
    file = open(outname,"w")
    file.write(sb)
    file.close()
    print ("End Sentiment Analysis on :",sheet)

