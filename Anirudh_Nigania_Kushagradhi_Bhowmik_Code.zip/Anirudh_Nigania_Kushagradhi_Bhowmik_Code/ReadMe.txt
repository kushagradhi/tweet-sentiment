CS583 Project 2 Twitter Sentiment Analysis 
Anirudh Nigania
Kushagradhi Bhowmik

Folder Structure
1. Demo - Contains all the relevant code for running the test data during demo
	a. data - Contains the training and test data files
	b. main.py - Contains the code for running the classifier
	c. Preprocessing.py - Contains the code for the preprocessing step
	d. LogisticRegression.py - Contains the code for logistic regression
	e. Utils.py - Contains the code for utility functions
2. Others - Contains the code for various machine learning algorithms that we tried implementing, and code for Training and Cross Validation

Instructions for running the code:-
1. cd to - Anirudh_Nigania_Kushagradhi_Bhowmik_Code
2. cd to - Demo
3. python main.py
4. Obama DataSet Output - Anirudh_Nigania_Kushagradhi_Bhowmik_Obama.txt
5. Romney DataSet Output - Anirudh_Nigania_Kushagradhi_Bhowmik_Romney.txt